const randomInt = (min, max) => {
  return Math.round(Math.random() * (max - min) + min);
};

const p = document.getElementById("year");
const reset = document.getElementById("reset");
const ptime = document.getElementById("time");
const time = new Date();
const ar = document.getElementById("ar");

ar.innerText = randomInt(6, 29) * 1000 + 990;
p.innerText = randomInt(2000, 2100);
reset.addEventListener("click", () => {
  p.innerText = randomInt(2000, 2100);
  ar.innerText = randomInt(6, 29) * 1000 + 990;
});

ptime.innerText = `${time.getHours().toString().padStart(2, "0")}:${time.getMinutes().toString().padStart(2, "0")}:${time.getSeconds().toString().padStart(2, "0")}`;
const timer = setInterval(() => {
  ptime.innerText = `${time.getHours().toString().padStart(2, "0")}:${time.getMinutes().toString().padStart(2, "0")}}:${time.getSeconds().toString().padStart(2, "0")}`;
}, 60000);
