﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BinaryTree
{
    internal class Program
    {
        static void Main(string[] args)
        {
            BinaryTree tree =new BinaryTree();
            tree.Insert(6);
            tree.Insert(7);
            tree.Insert(8);
            tree.Insert(9);
            tree.Insert(10);
            tree.Insert(1);
            tree.Insert(2);
            Console.WriteLine(tree.MinValue());
            Console.WriteLine();
            tree.InOrder();
            Console.WriteLine(tree.Contains(1));
            Console.WriteLine(tree.Contains(11));
        }
    }
}
