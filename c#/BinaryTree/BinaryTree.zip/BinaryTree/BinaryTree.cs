﻿using System;
using System.CodeDom;
using System.Collections.Generic;
using System.Linq;
using System.Security.AccessControl;
using System.Text;
using System.Threading.Tasks;

namespace BinaryTree
{
    class BinaryTree
    {
        Node root;
        public BinaryTree()
        {
            root = null;
        }
        private void InsertRecursive(Node current, Node newNode)
        {
            if(newNode.Data <= current.Data)
            {
                //left
                if (current.Left == null)
                {
                    current.Left = newNode;
                }
                else
                    InsertRecursive(current.Left, newNode);
            }
            else
            {
                //right
                if (current.Right == null)
                {
                    current.Right = newNode;
                }
                else
                    InsertRecursive(current.Right, newNode);

            }
        }
        public void Insert(int newElement)
        {
            Node newNode = new Node(newElement);
            if(root == null) 
            {
                root = newNode;
                return;
            }
            InsertRecursive(root, newNode);
        }
        private int MinFind(Node current)
        {
            if(current.Left == null)
            {
                return current.Data;
            }
            else
            {
                return MinFind(current.Left);
            }
        }
        public int MinValue()
        {
            return MinFind(root);
        }
        private void InOrder(Node node)
        {
            if(node == null)
            {
                return;
            }
            InOrder(node.Left);
            Console.WriteLine($"{node.Data}, ");
            InOrder(node.Right);
        }
        public void InOrder()
        {
            InOrder(root);
        }
        private bool Contains(Node node,int val)
        {
            if(node == null)
            {
                return false;
            }

            if(node.Data == val)
                return true;

            if(val < node.Data)
            {
                return Contains(node.Left, val);
            }
            else
            {
                return Contains(node.Right, val);
            }
        }
        public bool Contains(int val)
        {
            return Contains(root, val);
        }
    }
}
